#include "node.h"

Nodo::Nodo(Usuario u) : usuario(u), siguiente(nullptr) {}
