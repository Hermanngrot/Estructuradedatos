#include "lista_usuarios.h"
#include <QFile>
#include <QJsonDocument>
#include <QJsonArray>

ListaUsuarios::ListaUsuarios() : cabeza(nullptr) {}

ListaUsuarios::~ListaUsuarios() {
    Nodo* actual = cabeza;
    while (actual) {
        Nodo* temp = actual;
        actual = actual->siguiente;
        delete temp;
    }
}

void ListaUsuarios::agregarUsuario(const Usuario& u) {
    Nodo* nuevo = new Nodo(u);
    nuevo->siguiente = cabeza;
    cabeza = nuevo;
}

bool ListaUsuarios::verificarLogin(const QString& codigo, const QString& contrasena) const {
    Nodo* actual = cabeza;
    while (actual) {
        if (actual->usuario.codigo == codigo && actual->usuario.contrasena == contrasena)
            return true;
        actual = actual->siguiente;
    }
    return false;
}

void ListaUsuarios::guardarEnArchivo(const QString& nombreArchivo) const {
    QJsonArray arreglo;
    Nodo* actual = cabeza;
    while (actual) {
        arreglo.append(actual->usuario.toJson());
        actual = actual->siguiente;
    }

    QFile archivo(nombreArchivo);
    if (archivo.open(QIODevice::WriteOnly)) {
        QJsonDocument doc(arreglo);
        archivo.write(doc.toJson());
        archivo.close();
    }
}

void ListaUsuarios::cargarDesdeArchivo(const QString& nombreArchivo) {
    QFile archivo(nombreArchivo);
    if (archivo.open(QIODevice::ReadOnly)) {
        QByteArray datos = archivo.readAll();
        archivo.close();

        QJsonDocument doc = QJsonDocument::fromJson(datos);
        QJsonArray arreglo = doc.array();

        for (const QJsonValue& valor : arreglo) {
            Usuario u = Usuario::fromJson(valor.toObject());
            agregarUsuario(u);
        }
    }
}

