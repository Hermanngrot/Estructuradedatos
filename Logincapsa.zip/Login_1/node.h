#ifndef NODE_H
#define NODE_H

#include "usuarios.h"

class Nodo {
public:
    Usuario usuario;
    Nodo* siguiente;

    Nodo(Usuario u);
};

#endif // NODE_H
