#include "usuarios.h"

Usuario::Usuario(QString c, QString p) : codigo(c), contrasena(p) {}

QJsonObject Usuario::toJson() const {
    QJsonObject obj;
    obj["codigo"] = codigo;
    obj["contrasena"] = contrasena;
    return obj;
}

Usuario Usuario::fromJson(const QJsonObject &obj) {
    QString c = obj["codigo"].toString();
    QString p = obj["contrasena"].toString();
    return Usuario(c, p);
}
