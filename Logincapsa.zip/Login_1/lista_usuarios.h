#ifndef LISTA_USUARIOS_H
#define LISTA_USUARIOS_H

#include "node.h"
#include <QString>

class ListaUsuarios {
private:
    Nodo* cabeza;

public:
    ListaUsuarios();
    ~ListaUsuarios();

    void agregarUsuario(const Usuario& u);
    bool verificarLogin(const QString& codigo, const QString& contrasena) const;

    void guardarEnArchivo(const QString& nombreArchivo) const;
    void cargarDesdeArchivo(const QString& nombreArchivo);
};

#endif // LISTA_USUARIOS_H
