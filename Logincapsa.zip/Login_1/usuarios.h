#ifndef USUARIOS_H
#define USUARIOS_H

#include <QString>
#include <QJsonObject>

class Usuario {
public:
    QString codigo;
    QString contrasena;

    Usuario(QString c = "", QString p = "");

    QJsonObject toJson() const;
    static Usuario fromJson(const QJsonObject &obj);
};

#endif // USUARIOS_H
