#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPainter>
#include <QPainterPath>
#include <QPixmap>
#include <QApplication>
#include <QMessageBox>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setRoundedImage();
    ui->stackedWidget->hide();
    listaUsuarios.cargarDesdeArchivo("usuarios.json");
}
void MainWindow::setRoundedImage()
{
    QPixmap pixmap(":/new/prefix1/capsa.qrc.png"); // Asegúrate que la ruta coincida con tu archivo .qrc
    QPixmap roundedPixmap(pixmap.size());
    roundedPixmap.fill(Qt::transparent);

    QPainter painter(&roundedPixmap);
    painter.setRenderHint(QPainter::Antialiasing);

    QPainterPath path;
    int radius = 30;

    // Solo esquina superior izquierda redondeada
    path.moveTo(radius, 0);
    path.arcTo(0, 0, 2 * radius, 2 * radius, 90, 90);
    path.lineTo(0, pixmap.height());
    path.lineTo(pixmap.width(), pixmap.height());
    path.lineTo(pixmap.width(), 0);
    path.lineTo(radius, 0);
    path.closeSubpath();

    painter.setClipPath(path);
    painter.drawPixmap(0, 0, pixmap);

    ui->capslogin->setPixmap(roundedPixmap);
}
MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_LoginButton_clicked()
{
    QString usuario = ui->usuario->text();
    QString contrasena = ui->clave->text();

    if (usuario.isEmpty() || contrasena.isEmpty()) {
        QMessageBox::warning(this, "Login", "Por favor complete ambos campos.");
        return;
    }

    // Verificar si el usuario está registrado
    if (listaUsuarios.verificarLogin(usuario, contrasena)) {
        QMessageBox::information(this, "Login", "Inicio de sesión exitoso.");
        // Aquí podrías abrir otra ventana o continuar al sistema
    } else {
        QMessageBox::critical(this, "Login", "Usuario o contraseña incorrectos.");
    }
}


void MainWindow::on_registrarButton_clicked(){
    ui->stackedWidget->show();
    ui->stackedWidget->setCurrentIndex(0);
}


void MainWindow::on_salirButton_clicked()
{
    QApplication::quit();
}


void MainWindow::on_siboton_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);
}


void MainWindow::on_NOboton_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
    ui->stackedWidget->hide();
}


void MainWindow::on_salir_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}


void MainWindow::on_comprobar_clicked()
{
    QString usuario = ui->adminname->text();
    QString clave = ui->claveadmin->text();

    if (usuario == "Hermann" && clave == "2024116248") {
        ui->stackedWidget->setCurrentIndex(1);
    } else {
        QMessageBox::warning(this, "Error", "Usuario o contraseña incorrectos.");
    }
}


void MainWindow::on_salir_2_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
    ui->stackedWidget->hide();
}


void MainWindow::on_guardar_clicked()
{
    QString usuario = ui->Usuarioregistro->text();
    QString clave = ui->claveregistro->text();
    QString claveVerificacion = ui->verificarclaveregistro->text();

    if (usuario.isEmpty() || clave.isEmpty() || claveVerificacion.isEmpty()) {
        QMessageBox::warning(this, "Campos vacíos", "Por favor, completa todos los campos.");
        return;
    }

    if (clave != claveVerificacion) {
        QMessageBox::warning(this, "Error de contraseña", "Las contraseñas no coinciden.");
        return;
    }

    Usuario nuevo(usuario, clave);
    listaUsuarios.agregarUsuario(nuevo);

    listaUsuarios.guardarEnArchivo("usuarios.json");

    QMessageBox::information(this, "Registro exitoso", "Usuario registrado correctamente.");
    ui->Usuarioregistro->clear();
    ui->claveregistro->clear();
    ui->verificarclaveregistro->clear();
    ui->stackedWidget->setCurrentIndex(0);
    ui->stackedWidget->hide();
}

