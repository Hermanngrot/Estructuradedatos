#pragma once
#include "Nodo.h"

class ColaDoble {
private:
    Nodo* frente;
    Nodo* fin;

public:
    ColaDoble();
    ~ColaDoble();

    bool estaVacia() const;

    void encolarFrente(int valor);
    void encolarFin(int valor);

    int desencolarFrente();
    int desencolarFin();

    void mostrar() const;
};

