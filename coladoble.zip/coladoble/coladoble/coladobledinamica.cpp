#include <iostream>
#include "ColaDoble.h"
using namespace std;

int main() {
    ColaDoble miCola;

    miCola.encolarFin(10);
    miCola.encolarFin(20);
    miCola.encolarFrente(5);
    miCola.encolarFrente(1);

    miCola.mostrar();

    cout << "Desencolando del frente: " << miCola.desencolarFrente() << endl;
    miCola.mostrar();

    cout << "Desencolando del fin: " << miCola.desencolarFin() << endl;
    miCola.mostrar();

    return 0;
}
