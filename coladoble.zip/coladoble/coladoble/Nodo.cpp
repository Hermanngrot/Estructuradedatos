#include "Nodo.h"

Nodo::Nodo(int valor) {
    dato = valor;
    siguiente = nullptr;
    anterior = nullptr;
}

void Nodo::setDato(int valor) {
    dato = valor;
}

int Nodo::getDato() const {
    return dato;
}

void Nodo::setSiguiente(Nodo* nodo) {
    siguiente = nodo;
}

Nodo* Nodo::getSiguiente() const {
    return siguiente;
}

void Nodo::setAnterior(Nodo* nodo) {
    anterior = nodo;
}

Nodo* Nodo::getAnterior() const {
    return anterior;
}
