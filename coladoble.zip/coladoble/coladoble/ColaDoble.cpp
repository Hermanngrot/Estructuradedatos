#include "ColaDoble.h"
#include <iostream>
using namespace std;

ColaDoble::ColaDoble() {
    frente = nullptr;
    fin = nullptr;
}

ColaDoble::~ColaDoble() {
    while (!estaVacia()) {
        desencolarFrente();
    }
}

bool ColaDoble::estaVacia() const {
    return frente == nullptr;
}

void ColaDoble::encolarFrente(int valor) {
    Nodo* nuevo = new Nodo(valor);

    if (estaVacia()) {
        frente = fin = nuevo;
    }
    else {
        nuevo->setSiguiente(frente);
        frente->setAnterior(nuevo);
        frente = nuevo;
    }
}

void ColaDoble::encolarFin(int valor) {
    Nodo* nuevo = new Nodo(valor);

    if (estaVacia()) {
        frente = fin = nuevo;
    }
    else {
        fin->setSiguiente(nuevo);
        nuevo->setAnterior(fin);
        fin = nuevo;
    }
}

int ColaDoble::desencolarFrente() {
    if (estaVacia()) {
        cout << "La cola doble est� vac�a. No se puede desencolar por el frente.\n";
        return -1;
    }

    int valor = frente->getDato();
    Nodo* temp = frente;
    frente = frente->getSiguiente();

    if (frente != nullptr) {
        frente->setAnterior(nullptr);
    }
    else {
        fin = nullptr;
    }

    delete temp;
    return valor;
}

int ColaDoble::desencolarFin() {
    if (estaVacia()) {
        cout << "La cola doble est� vac�a. No se puede desencolar por el fin.\n";
        return -1;
    }

    int valor = fin->getDato();
    Nodo* temp = fin;
    fin = fin->getAnterior();

    if (fin != nullptr) {
        fin->setSiguiente(nullptr);
    }
    else {
        frente = nullptr;
    }

    delete temp;
    return valor;
}

void ColaDoble::mostrar() const {
    if (estaVacia()) {
        cout << "La cola doble est� vac�a.\n";
        return;
    }

    Nodo* actual = frente;
    cout << "Cola doble (frente -> fin): ";
    while (actual != nullptr) {
        cout << actual->getDato() << " ";
        actual = actual->getSiguiente();
    }
    cout << endl;
}
