#pragma once

class Nodo {
private:
    int dato;
    Nodo* siguiente;
    Nodo* anterior;

public:
    Nodo(int valor);

    void setDato(int valor);
    int getDato() const;

    void setSiguiente(Nodo* nodo);
    Nodo* getSiguiente() const;

    void setAnterior(Nodo* nodo);
    Nodo* getAnterior() const;
};
